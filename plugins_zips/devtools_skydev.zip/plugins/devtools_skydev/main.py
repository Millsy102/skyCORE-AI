def run():
    print("skyDEV Plugin DevTools activated")
